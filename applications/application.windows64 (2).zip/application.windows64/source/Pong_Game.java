import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Pong_Game extends PApplet {

Ball ball;
Paddle paddle;
ArrayList<Decor> decors;
int score;
int level;
boolean done;

public void setup() {
  
  ball = new Ball(width/2, height/2, 5);
  ball.speedX = 5;
  ball.speedY = random(-5, 5);
  paddle = new Paddle();
  score = 0;
  level = 1;
  decors = new ArrayList();
}

public void draw() {
  background(0);
  decors.add(new Decor(PApplet.parseInt(random(width)), PApplet.parseInt(random(height))));
  for (int i = 0; i < decors.size(); i++) {
    Decor decor = decors.get(i);
    decor.display();
    decor.move();
    if (decor.reachedBottom()) {
      decors.remove(decor);
    }
  }
  paddle.display();
  ball.move();
  ball.display();
  if (ball.x > width) {
    ball.speedX = -ball.speedX;
    if (level > 1 && !done) {
      ball.speedX *= 1.2f;
      ball.speedY *= 1.2f;
      done = true;
    }
  }

  if (ball.x < 0) {
    ball.speedX = -ball.speedX;
    if (level > 1 && !done) {
      ball.speedX *= 1.2f;
      ball.speedY *= 1.2f;
      done = true;
    }
  }

  if (ball.y > height) {
    ball.x = width/2;
    ball.y = height/2;
    if (level < 2) {
      ball.speedY = random(-5, 5);
    } else {
      if (level > 1 && !done) {
        ball.speedX *= 1.2f;
        ball.speedY *= 1.2f;
        done = true;
      }
    }
    ball.health -=1;
  }

  if (ball.y < 0) {
    ball.speedY = -ball.speedY;
    if (level > 1 && !done) {
      ball.speedX *= 1.2f;
      ball.speedY *= 1.2f;
      done = true;
    }
  }

  if (ball.x < mouseX+50 && ball.x > mouseX-50 && ball.y > 450 && ball.y < 452) {
    ball.speedY = -ball.speedY;
    if (level > 1 && !done) {
      ball.speedX *= 1.2f;
      ball.speedY *= 1.2f;
      done = true;
    }
    score += 1;
  }
  
  if (score > 5 && level < 2) {
    level += 1;
  }

  if (score > 10) {
    fill(0);
    rect(250, 250, 500, 500);
    fill(255);
    text("You Win!", width/2, height/2);
  }

  if (ball.health < 1) {
    fill(0);
    rect(250, 250, 500, 500);
    fill(255);
    text("You Lose LOL!", width/2, height/2);
  }
  infoPanel();
}

public void infoPanel() {
  fill(128, 128);
  rectMode(CORNER);
  rect(0, 0, 500, 50);
  fill(255, 128);
  text("Health:" + ball.health, 20, 20);
  text("Score:" + score, 100, 20);
  text("Level:" + level, 180, 20);
  text("Welcome to the Pong Game,", 260, 20);
  text("move your mouse to control the paddle,", 260, 30);
  text("don't let the ball touch the bottom", 260, 40);
}
class Ball { 
  float x;
  float y;
  float speedX;
  float speedY;
  float diameter;
  int c;
  float health;

  Ball(float x, float y, float health) {
    this.x = x;
    this.y = y;
    this.health = health;
    speedX = 0;
    speedY = 0;
    c = (225);
  }

  public void move() {
    y = y + speedY;
    x = x + speedX;
  }

  public void display() {
    fill(c);
    ellipse(x, y, 50, 50);
  }
}
class Decor {

  int x, y, speed, dia;
  int c;

  Decor(int x, int y) {
    this.x = x;
    this.y = y;
    c = color(255,255,0);
    speed = PApplet.parseInt(1);
    dia = PApplet.parseInt(random(4,10));
  }

  public void display() {
    rectMode(CENTER);
    noStroke();
    fill(c);
    rect(x, y, dia, dia);
  }

  public void move() {
    y+=speed;
  }

  public boolean reachedBottom() {
    if (y> height+50) {
      return true;
    } else {
      return false;
    }
  }
}
class Paddle {
  float x;
  int c;

  Paddle() {
    c = (225);
  }

  public void display() {
    fill(c);
    if (mouseX+50 < width) {
      rectMode(CENTER);
      rect(mouseX, 530, 100, 100);
    } else {
      rectMode(CENTER);
      rect(450, 530, 100, 100);
    }
  }
}
  public void settings() {  size(500, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Pong_Game" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
